
public class Maintest {
		/*public static void main(String args[]) throws ElementexistantException
		{
			
			PieceDeBase v=new PieceDeBase(42,"pointe",5);
			PieceDeBase k=new PieceDeBase(67,"clous",15);
			PieceComposite H=new PieceComposite(1445,"cuisine",5);
			H.ajouterpiece(v,2);
			H.ajouterpiece(k,2);
			H.ajouterpiece(H, 5);
			H.affiche_tous_les_sous_composants(5);
			
		}*/

}


