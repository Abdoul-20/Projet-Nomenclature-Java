
public class Lampe extends Piece {
	protected int Puissance;
	public Lampe(int ref,String deno,double poids,int puiss)
	{
		super(ref,deno,poids);
		this.Puissance=puiss;
	}
	@Override
	protected boolean estcomposantede(Piece p) {
		// TODO Auto-generated method stub
		return false;
	}

}
