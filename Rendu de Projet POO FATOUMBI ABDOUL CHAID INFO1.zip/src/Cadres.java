import java.util.ArrayList;
public class Cadres extends PieceComposite {
	ArrayList<Piecefragile> liste=new ArrayList<Piecefragile>();
	public Cadres(int ref,String deno,double poids)
	{
		super(ref,deno,poids);
	}

}
