import java.util.*;
public class PieceComposite extends Piece{    //Ok
	LinkedList<Paire<Piece,Integer>> Listedepiece;
	public PieceComposite(int ref,String deno,double poids)

	{
		super(ref,deno,poids);
		Listedepiece=new LinkedList<Paire<Piece,Integer>>();
		
	}
	public void ajouterpiece(Piece P,Integer i) throws ElementexistantException
	{ 
		Paire<Piece,Integer>newelement=new Paire<Piece,Integer>(P,i);
		if(!(P.estcomposantede(this)))
		{
			Listedepiece.add(newelement);//Pour l'ajout d'une Piece
		}
		else 
			throw new ElementexistantException();
	}
	public String toString()

	{
		return super.toString()+"\n"+affiche_tous_les_sous_composants(4);
	}

	public String affiche_tous_les_sous_composants(int decal)//A mieux compendre 
	{
		String ret = "", espaces = "";
		  for(Paire<Piece, Integer> paire: Listedepiece){
		    for(int i = 0; i < decal; i++)
		      espaces += " ";
		    ret += espaces + paire.getPiece() + "\n";
		    if(paire.getPiece() instanceof PieceComposite)
		      ret += ((PieceComposite) paire.getPiece()).affiche_tous_les_sous_composants(decal + 3);
		    
		  }
		  return ret;
	}
	public boolean estcomposantede(Piece P)
	{
		if(this.equals(P)) //Dans le cas ou les deux pi�ces sont les memes 
		{
			return true;
		}
			for(Paire<Piece,Integer>element:this.Listedepiece)
			{
				if(element.getPiece().estcomposantede(P))
				{
					System.out.println("Votre �l�ment s'y trouve\n ");
					return true;
					
				}
			}
		return false;
		
		
	}
	public double getPoids()
	{
				double b=0;
		
				for(Paire<Piece,Integer>element:(this.Listedepiece))
				{
					b=b+(element.getPiece()).getPoids();
				}
			    b=b+this.poids;
		return b;
	}
}
