
public class PieceDeBase extends Piece {    //OK
	public PieceDeBase (int ref,String deno,double poids)
	{
		super(ref,deno,poids);
	}
	public boolean estcomposantede(Piece P)
	{
		if(this.equals(P))
		  return true;
		return false;
		 
	}

}
