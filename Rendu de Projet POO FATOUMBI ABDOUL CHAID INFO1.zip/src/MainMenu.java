import java.util.Collections;
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;
public class MainMenu{
		public static void main(String[] args) throws ElementexistantException, IOException
		{	
			Menu();
			
		}

public static void  Menu() throws ElementexistantException, IOException {
		boolean exit=false;
		Scanner sc=new Scanner(System.in);
		int a;
		Nomenclature user=null;
		while(!exit)
		{
			System.out.println("0-EXIT \n"+"1-Nouvelle nomenclature \n"+"2-Ajouter une pi�ece sans ces composants \n"+"3-Afficher la nomenclature\n"+"4-Liste les pi�eces de meme denomination\n"+ "5-Ajouter un composant �  une pi�ece \n"+"6-Afficher tous les details d'une piece \n"+"7-Supprimer une pi�ce \n"+"8-Trier par r�f�rence \n"+"9-Afficher les pi�ces de base \n "+"10-Sauvegarder \n"+"11-Lire une nomenclature \n");
			System.out.println("Indiquer la tache que vous souhaitez svp en saisissant un num�ro soit 0 1 2 3 4 5 6 ou 7 \n");
			a=sc.nextInt();
		switch(a) {
		case 0:	
			{	exit=true;
				System.out.println("Vous etes sorti du menu \n");
				break;
			}
		case 1:
			{	try
				{
				@SuppressWarnings("resource")
				Scanner s1=new Scanner(System.in);
				System.out.println("Entrer le nom de la nomenclature que vous voulez cr�er \n ");
				String str=s1.nextLine();
				user=new Nomenclature(str);
				System.out.println("Votre Nomenclature "+str+" vient d'etre cr�er \n");
				}
				catch(RuntimeException e)
				{
					System.out.println("Il y a une erreur dans la saisie");
				}
				break;
			}
				
		case 2:
			{
				if(user instanceof Nomenclature)
				{   try
				{
					@SuppressWarnings("resource")
					Scanner s4=new Scanner(System.in);
					System.out.println("Entrer le nom de la pi�ce que vous souhaitez cr�er \n ");
					String str=s4.nextLine();
					System.out.println(str);
					System.out.println("Entrer le num�ro de r�f�rence \n ");
					int str2=s4.nextInt();
					System.out.println("Entrer le poids de la pi�ce \n ");
					double str3=s4.nextDouble();
					System.out.println("Est-ce une pi�ce de base ou une pi�ce composite ?Pour une pi�ce de base tapez 21 pour une pi�ce composite 22 \n ");
					int st=s4.nextInt();
					if(st==21)
					{
						PieceDeBase P=new PieceDeBase(str2,str,str3);
						user.addpiece(P);
					}
					else if(st==22)
					{
						PieceComposite P=new PieceComposite(str2,str,str3);
						user.addpiece(P);
					}
				}catch(RuntimeException e)
				{
					System.out.println("Vous avez mal saisie une donn�e veuillez verifier les domaine de valeur puis r�essayer ");
				}
			}
				else 
					System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");
				break;
			}
		case 3:
			{	if(user instanceof Nomenclature)
					System.out.println(user.toString());//Pour affichage de la nomenclature 
				else
					System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");
				break;
			}
		case 4:
			{
				if(user instanceof Nomenclature)
				{
					try
					{
					System.out.println("Entrer la d�nomination des pi�ces que vous recherchez SVP\n");
					String deno=sc.next();
					for(Piece element:user.Tabledepiece)
					{
						if((element.getdenomination()==deno) )
						{
							System.out.println(element.toString());
						}
					}
					}catch(RuntimeException e)
					{
						System.out.println("Vous avez mal saisie une donn�e veuillez verifier les domaine de valeur puis r�essayer ");
					}
				}
				else 
					System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");	
				
				break;
			}
		case 5:
			{   
				if(user instanceof Nomenclature)
				{
					try {
					System.out.println("Entrer la r�f�rence de la pi�ce auquel vous voulez ajouter une autre pi�ce");
					int ref=sc.nextInt();
					System.out.println("Entrer le nom de la nouvelle pi�ce � jouter \n");
					String nom=sc.next();
					System.out.println("Entrer le num�ro de r�f�rence \n ");
					int refe=sc.nextInt();
					System.out.println("Entrer le poids de la pi�ce \n ");
					double poi=sc.nextDouble();
					System.out.println("Est-ce une pi�ce de base ou une pi�ce composite ?Pour une pi�ce de base tapez 1 pour une pi�ce composite 2 \n ");
					int st=sc.nextInt();
					System.out.println("Nombre d'occurence de la pi�ce SVP");
					Integer sh=sc.nextInt();
					if(st==21)   //Il tape 21 si c'est une pi�ce de Base qu'il veut rajouter 
					{
						PieceDeBase P=new PieceDeBase(refe,nom,poi);
						for(Piece element:user.Tabledepiece)
						{
							if((element.reference==ref) &&(element instanceof PieceComposite))
									((PieceComposite) element).ajouterpiece(P,sh);
							else
								System.out.println("Impossible d'ajouter votre pi�ce soit votre r�f�rence est incoorecte soit votre pi�ce n'est pas une pi�ce composite et ne peut contenir d'autres �l�ments");
						}
					}
					else if(st==22) //22 si c'est une pi�ce composite qu'il souhaite rajouter
					{
						PieceComposite P=new PieceComposite(refe,nom,poi);
						for(Piece element:user.Tabledepiece)
						{
							if((element.reference==ref) &&(element instanceof PieceComposite))
									((PieceComposite) element).ajouterpiece(P,sh);
							else
								System.out.println("Impossible d'ajouter votre pi�ce soit votre r�f�rence est incoorecte soit votre pi�ce n'est pas une pi�ce composite et ne peut contenir d'autres �l�ments");
							
						}
					}
					}catch(RuntimeException e)
					{
						System.out.println("Vous avez mal saisie une donn�e veuillez verifier les domaine de valeur puis r�essayer ");
					}
				}
					
					else
						System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");
					break;
	
			}
		case 6:
			{
				if(user instanceof Nomenclature)
				{
					try {
					System.out.println("Entrer la r�f�rence de la pi�ce dont vous voulez afficher les d�tails\n ");
					int ref=sc.nextInt();
					if(!(user.rechercherunElement(ref)))
					{
						System.out.println("Votre �l�ment n'existe pas je suis navr�");
						
					}
					else
						for(Piece element:user.Tabledepiece)
						{
							if(element.getreference()==ref)
								System.out.println(element.toString());
						}
					}catch(RuntimeException e)
				{
						System.out.println("Vous avez mal saisie une donn�e veuillez verifier les domaine de valeur puis r�essayer ");
				}
						
					
				}
				else
					System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");
				break;
			}
		case 7:
			{
				if(user instanceof Nomenclature)
				{   try {
					System.out.println("Entrer la r�f�rence de la pi�ce que vous voulez supprimer");
					int ref=sc.nextInt();
					for(Piece element:user.Tabledepiece)
					{
						if(element.reference==ref)
							user.SupprimerElement(element);//On supprime l'�l�ment 
					}
				}catch(RuntimeException e)
				{
					System.out.println("Vous avez mal saisie une donn�e veuillez verifier les domaine de valeur puis r�essayer ");
				}
					
				}
				else
					System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");
				
				break;
			}
		case 8:
		{
			if(user instanceof Nomenclature)
			{
				Collections.sort(user.Tabledepiece,new Trie());
			}
			else
				System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");	
			
			break;
		}
		case 9:
		{
			if(user instanceof Nomenclature)
			{
				for(Piece element:user.Tabledepiece)
				{
					if(element instanceof PieceDeBase)
					{
						System.out.println(element.toString());
					}
				}
			}
			else
				System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");
			break;
		}
		case 10:
		{
			if(user instanceof Nomenclature)
			{

				PieceComposite newpiece = null;
				PrintWriter ecriture=new PrintWriter("fichier.txt");
				ecriture.println(user.nom+"  "+user.Tabledepiece.size());
				for(Piece element:user.Tabledepiece)
			{
				ecriture.println(element.reference+" "+element.getdenomination()+" "+element.getPoids());
				if(element instanceof PieceComposite)
				{
					newpiece=(PieceComposite) element;
				
				for(Paire<Piece,Integer> element1:newpiece.Listedepiece)
				{
					ecriture.println(" "+element1.getPiece().getreference()+" "+element1.getInteger());
				}
				
				}
				ecriture.println(" -1 -1 ");
			}
			
			ecriture.close();
			}
			else
				System.out.println("Je suis d�sol� mais vous n'avez pas de nomenclature instanci� je vous exhorte � le faire\n");
			break;
		}
		case 11:
		{
				try
				{
				System.out.println("Veuillez entrez le nom de la nomenclature � charger\n");
				String scan=sc.next();//Le scanner la lecture
				java.io.File fichier=new java.io.File(scan);
				Scanner fichier1=new Scanner(fichier);
				String[] contenu;// Ce tableau de String servira � r�cuperer les �l�ment se trouvant � l'int�rieur du fichier un � un 
				contenu=fichier1.nextLine().split("\s");
				user=new Nomenclature(contenu[0]);
				int nb=Integer.parseInt(contenu[1]);
				int str1,str2;
				String chaine;
				String[] cont;
				for(int i=0;i<nb;i++)
				{
					contenu=fichier1.nextLine().split("\s");
					chaine=fichier1.nextLine().stripIndent();
					cont=chaine.split("\s");
					str1=Integer.parseInt(cont[0]);
					str2=Integer.parseInt(cont[1]);
					if(str1==-1)
					{
						PieceDeBase B=new PieceDeBase(Integer.parseInt(contenu[0]),contenu[1],Double.parseDouble(contenu[2]));
						user.addpiece(B);
					}
					else
					{
						PieceComposite H=new PieceComposite(Integer.parseInt(contenu[0]),contenu[1],Double.parseDouble(contenu[2]));
						user.addpiece(H);
						while(str1!=-1)
						{
							chaine=fichier1.nextLine().stripIndent();
							cont=chaine.split("\s");
							str1=Integer.parseInt(cont[0]);
							
						}
					}
					
				}fichier1.close();
				fichier1=new Scanner(fichier);
				fichier1.nextLine();
				for(int i=0;i<nb;i++)
				{
					contenu=fichier1.nextLine().split("\s");
					Piece P=user.renvoyerPiece(Integer.parseInt(contenu[0]));
					chaine=fichier1.nextLine().stripIndent();
					cont=chaine.split("\s");
					str1=Integer.parseInt(cont[0]);
					str2=Integer.parseInt(cont[1]);
					while(str1!=-1)
					{
						Piece P2=user.renvoyerPiece(str1);
							((PieceComposite)P).ajouterpiece(P2,str2);
							chaine=fichier1.nextLine().stripIndent();
							cont=chaine.split("\s");
							str1=Integer.parseInt(cont[0]);
							str2=Integer.parseInt(cont[1]);
							
					}
					
					
				}
				fichier1.close();
				}catch(RuntimeException e)
				{
					System.out.println("Vous avez mal saisie une donn�e veuillez verifier les domaine de valeur puis r�essayer ");
				}
				break;
		}
		}
		
		

		
		
	}
	sc.close();
	}
}
	

