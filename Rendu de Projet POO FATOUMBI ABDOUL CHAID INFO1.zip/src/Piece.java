
public abstract  class  Piece {
			protected int reference;
			protected String denomination;
			protected double poids;
			protected Piece(int ref,String denomination,double poids)
			{
				this.reference=ref;
				this.denomination=denomination;
				this.poids=poids;
			}
			public int getreference()
			{
				return this.reference;
			}
			public String getdenomination()
			{
				return this.denomination;
			}
			public double getPoids()
			{
				return this.poids;
			}

			public String toString()

			{
				return "Reference: "+this.reference+" Denomination: "+this.denomination+" Poids: "+this.poids;
			}
			
			
			public boolean equals(Piece B)
			{
				if((this.denomination==B.denomination)&&(this.poids==B.poids)&&(this.reference==B.reference))
					return true;
				return false;
			}
			protected abstract boolean estcomposantede(Piece p);
			
			
			

}
