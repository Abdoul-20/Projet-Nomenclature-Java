import java.util.Comparator;

public class Trie implements Comparator <Piece> {

	@Override
	public int compare(Piece o1, Piece o2) {
	
		return Integer.compare(o1.getreference(),o2.getreference());
	}

	
}
