import java.util.*;
public  class Nomenclature  {
	LinkedList<Piece> Tabledepiece;
	protected String nom;
	public Nomenclature(String nom)
	{
		this.nom=nom;
		Tabledepiece=new LinkedList<Piece>();
	}
	public void addpiece(Piece P) throws ElementexistantException 
	{ 
		
		for(Piece element:Tabledepiece)
		{
			if(element.reference==P.reference)
				throw new ElementexistantException();
		}
		Tabledepiece.add(P);
		
	}
	public String toString()
	{
		String sr="";
		for(Piece element:Tabledepiece)
		{
			sr=sr+"\n"+element.getdenomination();
		}
		return sr;
		
	}
	public boolean rechercherunElement(int ref)
	{
		for(Piece element:Tabledepiece)
		{
				if(element.getreference()==ref)
					return true;
		}
		return false;
			
	}
	public void affichageDesPieceContenant(Piece A)
	{
		for(Piece element:Tabledepiece)
		{
			if (A.estcomposantede(element))
			{
				System.out.println(element.toString());
			}
		}
	}
	public void SupprimerElement(Piece H)
	{
		for(Piece element:Tabledepiece)
		{
			if((element instanceof PieceComposite)&&(H.estcomposantede(element)))
			{
							System.out.println("Impossible de supprimer cette pi�ce il entre dans la composition d'une autre pi�ce \n");
			}
			Tabledepiece.remove(H);
			System.out.println("L'�lement � bien �t� supprim�\n");
		}
		
	}
	public Piece renvoyerPiece(int num)
	{
		for(Piece element:this.Tabledepiece)
		{
			if(element.getreference()==num)
				return element;
		}
		return null;
	}
	
	
	
	
}