@SuppressWarnings("hiding")
	public class Paire<Piece,Integer> {  //OK
		protected Piece p;
		protected Integer i;
		public Paire(Piece p1,Integer i)
		{
			this.p=p1;
			this.i=i;
		}
		public Piece getPiece()
		{
			return this.p;
		}
		public Integer getInteger()
		{
			return this.i;
		}
		public String toString()
		{
			return p.toString()+" Occurence de la pi�ce "+i; 
		}

}
