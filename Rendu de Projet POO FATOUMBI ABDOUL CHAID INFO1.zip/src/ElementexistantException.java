
public class ElementexistantException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ElementexistantException(){
		super("L'�lement que vous essayez d'ajouter existe d�j� \n");
	}

}
